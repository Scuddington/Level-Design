﻿using UnityEngine;
using System.Collections;

public class ActivateSummonCircle : MonoBehaviour {

    public GameObject Circle;

    void Start()
    {
        Circle.SetActive(false);
    }

    void OnTriggerEnter()
    {
        Circle.SetActive(true);
    }

    void OnTriggerExit()
    {
        StartCoroutine(StopCircle());    
    }

    IEnumerator StopCircle()
    {
        yield return new WaitForSeconds(3);
        Circle.SetActive(false);
    }
}
